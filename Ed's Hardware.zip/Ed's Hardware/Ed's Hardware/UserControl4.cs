﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ed_s_Hardware
{
    public partial class UserControl4 : UserControl
    {
        public UserControl4()
        {
            InitializeComponent();
            Trans.BackColor = Color.FromArgb(135, Color.Black);
        }

        private void UserControl4_Load(object sender, EventArgs e)
        {
            timer1.Start();
            LBtime.Text = DateTime.Now.ToLongTimeString();
        }
    }
}
