﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;


namespace Ed_s_Hardware
{
    public partial class Login : MetroFramework.Forms.MetroForm 
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
               int left,
               int top,
               int right,
               int bottom,
               int width,
               int height
           );


        int intClicks = 0;

        static Login _instance;

        public static Login Instance
        {
            get
            {
                if (_instance == null)

                    _instance = new Login();
                return _instance;

            }

        }





        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\rikki\Documents\CW2.mdf;Integrated Security=True;Connect Timeout=30");

        int i;




        public Login()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 12, 12));
            
        }

       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
            ControlBox = true;
            //this.panel5.SendToBack();
            //TransparetBackground(label2);

            //this.AcceptButton = this.logButt;
            //System.Windows.Forms.Timer timer2 = new System.Windows.Forms.Timer();
            //timer2.Interval = 1000;//one second
            //timer2.Tick += new System.EventHandler(timer2_Tick);
            //timer2.Start();


            tbUser.Focus();

        }



        //private void button1_Click(object sender, EventArgs e)
        //{
        //    Application.Exit();
        //}

        //private void label1_Click(object sender, EventArgs e)
        //{

        //}

        //private void label2_Click(object sender, EventArgs e)
        //{

        //}

        //void TransparetBackground(Control C)
        //{
        //    C.Visible = false;

        //    C.Refresh();
        //    Application.DoEvents();

        //    Rectangle screenRectangle = RectangleToScreen(this.ClientRectangle);
        //    int titleHeight = screenRectangle.Top - this.Top;
        //    int Right = screenRectangle.Left - this.Left;

        //    Bitmap bmp = new Bitmap(this.Width, this.Height);
        //    this.DrawToBitmap(bmp, new Rectangle(0, 0, this.Width, this.Height));
        //    Bitmap bmpImage = new Bitmap(bmp);
        //    bmp = bmpImage.Clone(new Rectangle(C.Location.X + Right, C.Location.Y + titleHeight, C.Width, C.Height), bmpImage.PixelFormat);
        //    C.BackgroundImage = bmp;

        //    C.Visible = true;
        //}

        //private void label4_Click(object sender, EventArgs e)
        //{

        //}

        //private void label5_Click(object sender, EventArgs e)
        //{

        //}

        //private void panel5_Paint(object sender, PaintEventArgs e)
        //{

        //}

        private void logButt_Click(object sender, EventArgs e)
        {
            intClicks = intClicks++;
            if (string.IsNullOrEmpty(tbUser.Text))
            {
                
                MessageBox.Show(this, "Please enter your username.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbUser.Focus();
            }
            if (string.IsNullOrEmpty(tbPass.Text))
            {
                
                MessageBox.Show(this, "Please enter your password.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbPass.Focus();
            }
            try
            {
                i = 0;
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from Login where username= '" + tbUser.Text + "' and password='" + tbPass.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());
                tbUser.Text = "";
                tbPass.Text = "";



                if (i == 0)
                {
                    MessageBox.Show(this, "You've entered an incorrect username or password", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    //metroProgressBar1.Visible = true;
                    //timer1.Enabled = true;

                    MessageBox.Show(this, "Welcome, you are now logged in. ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
            }
            
            catch (Exception ex)
            {

                MessageBox.Show(this, ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
            intClicks++;

        }
    }
}
