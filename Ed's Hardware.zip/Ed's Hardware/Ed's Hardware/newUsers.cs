﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ed_s_Hardware
{
    public partial class newUsers : MetroFramework.Forms.MetroForm
    {
        public newUsers()
        {
            InitializeComponent();
        }

        private void newUsers_Load(object sender, EventArgs e)
        {

        }
    }
}
