﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Ed_s_Hardware
{
    public partial class UserControl1 : UserControl
    {
        //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\rikki\Documents\CW2.mdf;Integrated Security=True;Connect Timeout=30");
        //SqlCommand command;
        //DataTable dt = new DataTable();
        //string imgLoc = "";
        public UserControl1()
        {
            InitializeComponent();
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            //try
            //{

            //    OpenFileDialog dlg = new OpenFileDialog();
            //    dlg.Filter = "JPG Files(*.jpg)|*.jpg|PNG Files(*.png)|*.png|ALL Files(*.*)|*.*";
            //    dlg.Title = "Select Student Photo";
            //    if (dlg.ShowDialog() == DialogResult.OK)

            //    {
            //        imgLoc = dlg.FileName.ToString();
            //        StudentPhoto.ImageLocation = imgLoc;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

            //finally
            //{
            //    con.Close();
            //}
        }

        private void bntRecord_Click(object sender, EventArgs e)
        {
            
        }

        private void bntRecord_Click_1(object sender, EventArgs e)
        {
            newUsers newUser1 = new newUsers ();
            newUser1.Show(); // 
        }
    }
}
